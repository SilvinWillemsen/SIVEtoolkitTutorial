using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CustomGrabAttachment : MonoBehaviour
{
   [HideInInspector] public bool moveToStageWhenGrabbed = false; 
}
